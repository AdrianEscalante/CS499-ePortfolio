package com.example.cs360_inventoryapp_by_adrianescalante;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    private InventoryAdapter adapter;
    private final List<InventoryItem> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        MaterialButton btnSms = findViewById(R.id.btnSms);

        btnSms.setOnClickListener(v -> startActivity(new Intent(this, SmsActivity.class)));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // DB
        dbHelper = new DBHelper(this);

        // Views
        RecyclerView rvInventory = findViewById(R.id.rvInventory);
        MaterialButton btnAddItem = findViewById(R.id.btnAddItem);

        // Recycler View Setup
        rvInventory.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(items, item -> {
            // Delete callback from adapter
            boolean deleted = dbHelper.deleteItem(item.getId());
            if (deleted) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadItemsFromDb();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        },
                // Edit listener
                this::showUpdateQtyDialog);

        rvInventory.setAdapter(adapter);

        // Initial load
        loadItemsFromDb();

        // Add item button
        btnAddItem.setOnClickListener(v -> showAddItemDialog());
    }

    private void showAddItemDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        EditText etName = dialogView.findViewById(R.id.etItemName);
        EditText etQty = dialogView.findViewById(R.id.etItemQty);

        new AlertDialog.Builder(this).setTitle("Add Item").setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String qtyStr = etQty.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Name and quantity required", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;
            try {
                qty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            long id = dbHelper.addItem(name, qty);
            if (id != -1) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                loadItemsFromDb();
            } else {
                Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
            }
        })
                .setNegativeButton("Cancel", null).show();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void loadItemsFromDb() {
        items.clear();

        Cursor c = dbHelper.getAllItems(); // SELECT id, name, qty FROM inventory ORDER BY name ASC
        if (c != null) {
            try {
                int idCol = c.getColumnIndexOrThrow("id");
                int nameCol = c.getColumnIndexOrThrow("name");
                int qtyCol = c.getColumnIndexOrThrow("qty");

                while (c.moveToNext()) {
                    long id = c.getLong(idCol);
                    String name = c.getString(nameCol);
                    int qty = c.getInt(qtyCol);

                    items.add(new InventoryItem(id, name, qty));
                }
            } finally {
                c.close();
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void showUpdateQtyDialog(InventoryItem item) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_update_qty, null);

        EditText etQty = dialogView.findViewById(R.id.etNewQty);
        etQty.setText(String.valueOf(item.getQty()));

        new AlertDialog.Builder(this).setTitle("Update Quantity").setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
            String qtyStr = etQty.getText().toString().trim();
            if (qtyStr.isEmpty()) {
                Toast.makeText(this, "Quantity required", Toast.LENGTH_SHORT).show();
                return;
            }

            int newQty;
            try {
                newQty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = dbHelper.updateQty(item.getId(), newQty);
            Toast.makeText(this, ok ? "Quantity updated" : "Update failed", Toast.LENGTH_SHORT).show();

            if (ok) {
                loadItemsFromDb();

                maybeSendLowInventoryAlert(new InventoryItem(item.getId(), item.getName(), newQty));
            }
        })
                .setNegativeButton("Cancel", null).show();
    }

    @SuppressLint("UnlocalizedSms")
    private void maybeSendLowInventoryAlert(InventoryItem item) {
        int LOW_THRESHOLD = 3;

        if (item.getQty() <= LOW_THRESHOLD) {
            // Only send if permission is granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager.getDefault().sendTextMessage("5554", null, "Low inventory alert: " + item.getName() + " qty = " + item.getQty(),null, null);
                    Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                // Permission not granted
                Toast.makeText(this, "Low inventory, SMS permission not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}