package com.example.cs360_inventoryapp_by_adrianescalante;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

/**
 * Manages creation, access, and modification of the application's local SQLite database for user
 * accounts and inventory records.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "warehouse_inventory.db";
    private static final int DB_VERSION = 2;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    //Create the local tables required for user authentication and persistent inventory storage.
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table
        db.execSQL("CREATE TABLE users (" + "id INTEGER PRIMARY KEY AUTOINCREMENT," + "username TEXT UNIQUE NOT NULL," + "password TEXT NOT NULL" + ")");

        // Inventory table
        db.execSQL("CREATE TABLE inventory (" + "id INTEGER PRIMARY KEY AUTOINCREMENT," + "name TEXT NOT NULL," + "qty INTEGER NOT NULL DEFAULT 0" + ")");

        // Application settings table
        db.execSQL("CREATE TABLE app_settings (" + "id INTEGER PRIMARY KEY, " + "low_stock_threshold INTEGER NOT NULL DEFAULT 3" + ")");

        // Store the default low stock threshold
        db.execSQL("Insert INTO app_settings (id, low_stock_threshold) VALUES (1, 3)");
    }

    @Override
    // Current development migration strategy recreates the database tables. A future database enhancement
    // will replace this with data preserving migrations.
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Version 2 adds persistent application settings without deleting existing user accounts or inventory records.
        if (oldVersion < 2) {

            db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (" + "id INTEGER PRIMARY KEY, " + "low_stock_threshold INTEGER NOT NULL DEFAULT 3" + ")");

            db.execSQL("INSERT OR IGNORE INTO app_settings " + "(id, low_stock_threshold) VALUES (1, 3)");
        }
    }

    // Store and retrieve account information used by the application's current local authentication system.
    public boolean createUsers(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        long result = db.insert("users", null, cv);
        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password}
        );
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id FROM users WHERE username=?",
                new String[]{username}
        );
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    // Provide the basic create, read, update, and delete operations used to maintain persistent
    // inventory records.
    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("qty", qty);
        return db.insert("inventory", null, cv);
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT id, name, qty FROM inventory ORDER BY name ASC", null);
    }

    public boolean updateQty(long id, int newQty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("qty", newQty);
        int rows = db.update("inventory", cv, "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete("inventory", "id=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    /**
     * Retrieves the current low stock threshold from persistent settings.
     */
    public int getLowStockThreshold() {

        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.rawQuery("SELECT low_stock_threshold FROM app_settings WHERE id = 1", null);

        int threshold = 3;

        if (c.moveToFirst()) {
            threshold = c.getInt(0);
        }

        c.close();

        return threshold;
    }

    /**
     * Updates the persistent low stock threshold
     */
    public boolean updateLowStockThreshold(int newThreshold) {

        if (newThreshold < 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("low_stock_threshold", newThreshold);

        int rows = db.update("app_settings", cv, "id = ?", new String[]{"1"});

        return rows > 0;
    }
}
