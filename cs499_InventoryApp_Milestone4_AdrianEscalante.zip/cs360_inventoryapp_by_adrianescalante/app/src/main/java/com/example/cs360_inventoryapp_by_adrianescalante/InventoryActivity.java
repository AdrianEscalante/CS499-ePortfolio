package com.example.cs360_inventoryapp_by_adrianescalante;
/**
 * Controls the primary inventory user interface.
 * Handles user interactions and delegates inventory data operations to InventoryRepository-
 * rather than communicating directly with SQLite.
 */

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private InventoryRepository repository;

    private InventoryAdapter adapter;
    private int lowStockThreshold;
    private final List<InventoryItem> items = new ArrayList<>();
    private final List<InventoryItem> allItems = new ArrayList<>();

    // Initialize the inventory data layer and connect the RecyclerView to the adapter used to display
    // and modify inventory records.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        MaterialButton btnSms = findViewById(R.id.btnSms);

        btnSms.setOnClickListener(v -> startActivity(new Intent(this, SmsActivity.class)));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inventory
        repository = new InventoryRepository(this);
        lowStockThreshold = repository.getLowStockThreshold();

        // Views
        RecyclerView rvInventory = findViewById(R.id.rvInventory);
        MaterialButton btnAddItem = findViewById(R.id.btnAddItem);
        SearchView searchInventory = findViewById(R.id.searchInventory);
        Spinner sortSpinner = findViewById(R.id.sortSpinner);

        searchInventory.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {

                        applySearchAndSort(newText, sortSpinner.getSelectedItemPosition());

                        return true;
                    }
                }
        );

        sortSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                        applySearchAndSort(
                                searchInventory.getQuery().toString(), position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // Keep the current inventory display unchanged.

                    }
                }
        );

        // Configure callbacks so edit and delete requests from the adapter are handled by the
        // activity while data operations remain in the repository.
        rvInventory.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(items, item -> {
            // Delete callback from adapter
            boolean deleted = repository.deleteItem(item.getId());
            if (deleted) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadItemsFromDb();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        },
                // Edit listener
                this::showUpdateQtyDialog);

        rvInventory.setAdapter(adapter);

        // Sort dropdown options
        String[] sortOptions = {
                "Name A-Z", "Quantity: Low to High", "Quantity: High to Low", "Restock Priority"
        };

        ArrayAdapter<String> sortAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sortOptions);

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(sortAdapter);

        // Initial load
        loadItemsFromDb();

        // Add item button
        btnAddItem.setOnClickListener(v -> showAddItemDialog());

        MaterialButton btnThreshold = findViewById(R.id.btnThreshold);
        btnThreshold.setOnClickListener(v -> showThresholdDialog());
    }

    /**
     * Allows the user to update the low stock threshold stored in SQLite.
     */
    private void showThresholdDialog() {

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(lowStockThreshold));
        input.setSelectAllOnFocus(true);

        new AlertDialog.Builder(this)
                .setTitle("Low Stock Threshold")
                .setMessage("Enter the quantity that should trigger low stock alerts and restock priority.")
                .setView(input)
                .setPositiveButton("save", (dialog, which) -> {

                    String value = input.getText().toString().trim();

                    if (value.isEmpty()) {
                        Toast.makeText(this, "Threshold is required", Toast.LENGTH_SHORT).show();
                        return;

                }

                try {
                    int newThreshold = Integer.parseInt(value);

                    boolean updated = repository.updateLowStockThreshold(newThreshold);

                    if (updated) {
                        lowStockThreshold = newThreshold;

                        Toast.makeText(this, "Low-stock threshold updated to " + newThreshold, Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(this, "Unable to update threshold", Toast.LENGTH_SHORT).show();
                    }
        } catch (NumberFormatException e) {
                    Toast.makeText(this, "Enter a valid number", Toast.LENGTH_SHORT).show();
        }
    })
    .setNegativeButton("Cancel", null).show();
    }


    private void applySearchAndSort(String query, int sortPosition) {

        List<InventoryItem> filteredItems =
                InventoryAlgorithms.searchByName(allItems, query);

        List<InventoryItem> sortedItems =
                InventoryAlgorithms.sortByName(filteredItems);

        switch (sortPosition) {
            case 1:
                sortedItems = InventoryAlgorithms.sortByQuantityAscending(filteredItems);

                break;
            case 2:
                sortedItems = InventoryAlgorithms.sortByQuantityDescending(filteredItems);

                break;
            case 3:
                sortedItems = InventoryAlgorithms.getRestockPriority(filteredItems, lowStockThreshold);

                break;

            case 0:
            default:
                break;
        }

        displayItems(sortedItems);
    }

    /**
     * Displays the add item dialog, validates user input, and sends valid inventory data
     * to the repository for storage.
     */
    private void showAddItemDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        EditText etName = dialogView.findViewById(R.id.etItemName);
        EditText etQty = dialogView.findViewById(R.id.etItemQty);

        new AlertDialog.Builder(this).setTitle("Add Item").setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String qtyStr = etQty.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Name and quantity required", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;
            try {
                qty = Integer.parseInt(qtyStr);

                if (qty < 0) {
                    Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            long id = repository.addItem(name, qty);
            if (id != -1) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                loadItemsFromDb();
            } else {
                Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
            }
        })
                .setNegativeButton("Cancel", null).show();
    }

    /**
     * Refreshes the inventory displayed by the RecyclerView using data provided by the repository.
     */
    @SuppressLint("NotifyDataSetChanged")
    private void loadItemsFromDb() {
        allItems.clear();
        allItems.addAll(repository.getAllItems());

        displayItems(InventoryAlgorithms.sortByName(allItems));
    }

    /**
     * Updates the RecyclerView with the supplied inventory results.
     */
    @SuppressLint("NotifyDataSetChanged")
    private void displayItems(List<InventoryItem> displayList) {
        items.clear();
        items.addAll(displayList);
        adapter.notifyDataSetChanged();
    }

    /**
     * Displays the quantity update dialog and validates the new value before updating the selected
     * inventory item.
     */
    private void showUpdateQtyDialog(InventoryItem item) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_update_qty, null);

        EditText etQty = dialogView.findViewById(R.id.etNewQty);
        etQty.setText(String.valueOf(item.getQty()));

        new AlertDialog.Builder(this).setTitle("Update Quantity").setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
            String qtyStr = etQty.getText().toString().trim();
            if (qtyStr.isEmpty()) {
                Toast.makeText(this, "Quantity required", Toast.LENGTH_SHORT).show();
                return;
            }

            int newQty;
            try {
                newQty = Integer.parseInt(qtyStr);

                // Prevent invalid inventory states by rejecting negative quantities before the update
                // is sent to the repository.
                if (newQty < 0) {
                    Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = repository.updateQuantity(item.getId(), newQty);
            Toast.makeText(this, ok ? "Quantity updated" : "Update failed", Toast.LENGTH_SHORT).show();

            if (ok) {
                loadItemsFromDb();

                maybeSendLowInventoryAlert(new InventoryItem(item.getId(), item.getName(), newQty));
            }
        })
                .setNegativeButton("Cancel", null).show();
    }

    /**
     * Checks whether an updated item has reach the current low inventory threshold and sends an
     * SMS alert when permission is available.
     *
     * This function remains a candidate for extraction into a dedicated notification component in
     * a future enhancement.
     */
    @SuppressLint("UnlocalizedSms")
    private void maybeSendLowInventoryAlert(InventoryItem item) {

    if (item.getQty() <= lowStockThreshold) {
            // Only send if permission is granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager.getDefault().sendTextMessage("5554", null, "Low inventory alert: " + item.getName() + " qty = " + item.getQty(),null, null);
                    Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                // Permission not granted
                Toast.makeText(this, "Low inventory, SMS permission not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}