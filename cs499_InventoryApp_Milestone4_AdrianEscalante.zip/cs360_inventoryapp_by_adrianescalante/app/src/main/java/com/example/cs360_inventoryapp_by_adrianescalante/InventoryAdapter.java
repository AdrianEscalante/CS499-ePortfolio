package com.example.cs360_inventoryapp_by_adrianescalante;
/**
 * Connects InventoryItem data to the RecyclerView and forwards user edit and delete actions
 * to the owning activity through callbacks.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    public interface OnDeleteClickListener {
        void onDelete(InventoryItem item);
    }

    public interface OnEditClickListener {
        void onEdit(InventoryItem item);
    }

    private final List<InventoryItem> items;
    private final OnDeleteClickListener deleteClickListener;
    private final OnEditClickListener editListener;

    public InventoryAdapter(List<InventoryItem> items, OnDeleteClickListener deleteListener, OnEditClickListener editListener) {
        this.items = items;
        this.deleteClickListener = deleteListener;
        this.editListener = editListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory_row, parent, false);
        return new ViewHolder(view);
    }

    // Bind the inventory record to its row and connect user actions to the edit and delete callbacks.
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.tvName.setText(item.getName());
        holder.tvQty.setText("Qty: " + item.getQty());

        holder.tvQty.setOnClickListener(v -> editListener.onEdit(item));
        holder.itemView.setOnClickListener(v -> editListener.onEdit(item));
        holder.btnDelete.setOnClickListener(v -> deleteClickListener.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;
        MaterialButton btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvQty = itemView.findViewById(R.id.tvQty);
            btnDelete = itemView.findViewById(R.id.btnDeleteRow);
        }
    }
}
