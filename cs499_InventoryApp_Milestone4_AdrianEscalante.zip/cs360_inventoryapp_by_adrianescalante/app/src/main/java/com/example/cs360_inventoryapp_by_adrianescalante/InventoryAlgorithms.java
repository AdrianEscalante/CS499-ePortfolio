package com.example.cs360_inventoryapp_by_adrianescalante;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.PriorityQueue;

/**
 * Provides algorithms to used to search, sort, and prioritized inventory records.
 *
 * Keeping this logic separate from the database and user interface allows inventory data to be
 * processed without changing how it is stored.
 */
public final class InventoryAlgorithms {

    private InventoryAlgorithms() {
        // Utility class should not be instantiated.
    }

    /**
     * Performs linear search for inventory items whose names contain the user's search text.
     */
    public static List<InventoryItem> searchByName(
            List<InventoryItem> items, String query) {

        List<InventoryItem> results = new ArrayList<>();

        if (query == null || query.trim().isEmpty()) {
            results.addAll(items);
            return results;
        }

        String normalizedQuery =
                query.trim().toLowerCase(Locale.ROOT);

        for (InventoryItem item : items) {
            if (item.getName() != null && item.getName().toLowerCase(Locale.ROOT).contains(normalizedQuery)) {

                results.add(item);
            }
        }

        return results;
    }

    /**
     * Returns inventory alphabetically by item name.
     */
    public static List<InventoryItem> sortByName(
            List<InventoryItem> items) {

        List<InventoryItem> sortedItems = new ArrayList<>(items);

        Collections.sort(sortedItems, Comparator.comparingInt(InventoryItem::getQty));

        return sortedItems;
    }

    /**
     * Returns inventory from highest quantity to lowest quantity.
     */

    public static List<InventoryItem> sortByQuantityAscending(
            List<InventoryItem> items) {

        List<InventoryItem> sortedItems = new ArrayList<>(items);

        Collections.sort(sortedItems, Comparator.comparingInt(InventoryItem::getQty));

        return sortedItems;
    }

    public static List<InventoryItem> sortByQuantityDescending(
            List<InventoryItem> items) {

        List <InventoryItem> sortedItems = new ArrayList<>(items);

        Collections.sort(sortedItems, Comparator.comparingInt(InventoryItem::getQty).reversed());

        return sortedItems;
    }

    /**
     * Uses a PriorityQueue to identify low stock items and return them in restocking priority order.
     * Items with the lowest quantity receive the highest priority.
     */
    public static List<InventoryItem> getRestockPriority(
            List<InventoryItem> items, int threshold) {

        PriorityQueue<InventoryItem> restockQueue = new PriorityQueue<>(
                Comparator.comparingInt(InventoryItem::getQty).thenComparing(InventoryItem::getName,
                        String.CASE_INSENSITIVE_ORDER));

        for (InventoryItem item : items) {
            if (item.getQty() <= threshold) {
                restockQueue.offer(item);
            }
        }

        List<InventoryItem> prioritizedItems = new ArrayList<>();

        while (!restockQueue.isEmpty()) {
            prioritizedItems.add(restockQueue.poll());
        }

        return prioritizedItems;
    }
}
