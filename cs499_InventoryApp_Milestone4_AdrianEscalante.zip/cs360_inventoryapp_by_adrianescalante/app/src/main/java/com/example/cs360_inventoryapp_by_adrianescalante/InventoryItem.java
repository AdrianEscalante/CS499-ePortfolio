package com.example.cs360_inventoryapp_by_adrianescalante;

public class InventoryItem {
    private long id;
    private String name;
    private int qty;

    public InventoryItem(long id, String name, int qty) {
        this.id = id;
        this.name = name;
        this.qty = qty;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getQty() { return qty; }
}
