package com.example.cs360_inventoryapp_by_adrianescalante;
/**
 * Provides a data access layer between the user interface and SQLite database.
 * InventoryActivity interacts with this repository instead of directly processing database cursors
 * or calling DBHelper methods.
 */

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;
public class InventoryRepository {

    private final DBHelper dbHelper;

    public InventoryRepository(Context context) {
        dbHelper = new DBHelper(context.getApplicationContext());
    }

    /**
     * Retrieves all inventory records from the database and converts them into InventoryItem
     * objects that can be used by the user interface layer.
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();

        Cursor c = dbHelper.getAllItems();

        if (c != null) {
            try {
                int idCol = c.getColumnIndexOrThrow("id");
                int nameCol = c.getColumnIndexOrThrow("name");
                int qtyCol = c.getColumnIndexOrThrow("qty");

                // Convert each database row into an InventoryItem while keeping database-
                // specific Cursor processing inside the repository layer.
                while (c.moveToNext()) {
                    long id = c.getLong(idCol);
                    String name = c.getString(nameCol);
                    int qty = c.getInt(qtyCol);

                    items.add(new InventoryItem(id, name, qty));
                }
            // Always close the Cursor after processing to release the database resource.
            } finally {
                c.close();
            }
        }
        return items;
    }

    /**
     * Adds a new inventory item through the database helper
     */
    public long addItem(String name, int qty) {
        return dbHelper.addItem(name, qty);
    }
    public boolean updateQuantity(long id, int newQty) {
        return dbHelper.updateQty(id, newQty);
    }
    public boolean deleteItem(long id) {
        return dbHelper.deleteItem(id);
    }

    /**
     * Retrieves the store lows stock threshold.
     */
    public int getLowStockThreshold() {
        return dbHelper.getLowStockThreshold();
    }

    /**
     * Updates the stored low stock threshold
     */
    public boolean updateLowStockThreshold(int newThreshold) {
        return dbHelper.updateLowStockThreshold(newThreshold);
    }
}
